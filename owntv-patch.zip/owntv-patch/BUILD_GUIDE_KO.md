# OwnTV 커스텀 자막 3종 기능 패치 (소스 수정 완료)

## 무엇이 바뀌었나 (모두 실제 소스 수정본)

### 기능 1 — 앱 내장 자막 자동 재생
- 신규 파일: `app-src/.../player/BundledSubtitles.kt` (예: Bunny) 아래 라인 참고
- 사용: APK 빌드 전 `app/src/main/assets/subtitles/`에 자막(.srt/.vtt/.ass/.ssa/.sub)을 넣고 재빌드
- 매칭 규칙(순서대로):
  1. `mapping.json` — `{"영상제목일부": "자막파일.srt"}` (제목 부분 일치)
  2. 파일명 일치 — 영화 제목 "Big Buck Bunny" → "Big Buck Bunny.srt"
  3. 자막이 정확히 1개뿐이면 모든 영화/에피소드 재생 시 자동 부착·선택
- 동작: OwnTV_Core `SubtitleController.restoreForCurrentItem()`에 `autoAttachProvider` 훅을
  추가해, 영화/에피소드 재생 시작 시 `player.addExternalSubtitle(...)`로 즉시 attach+select
  → 영상이 시작되면 자막이 같이 자동 재생 (라이브 채널은 미적용)

### 기능 2 — 원하는 TTF 폰트로 자막 표시
- 신규 파일: `app-src/.../player/CustomSubtitleFont.kt`
- 사용: `app/src/main/assets/fonts/`에 .ttf/.otf 1개를 넣고 재빌드
- 동작:
  · mpv 엔진 자막 — 코어 `OwnTVPlayer.customSubFontFamily`(신규)가 `sub-font`에 반영,
    설정 폰트보다 우선하며 ASS 스타일도 덮어씀 (`sub-ass-override=force`)
  · 화면 오버레이 자막 — `SubtitleOverlay.kt`가 `Typeface.createFromAsset`으로 동일 폰트 적용
- 폰트 패밀리명은 TTF name 테이블(id 16/1)을 직접 파싱 (외부 라이브러리 0)

### 기능 3 — 연결부 (패치된 기존 파일)
- OwnTV_Core `player-core/.../OwnTVPlayer.kt` — `customSubFontFamily` 추가, mpv init/스타일 적용에 반영
- OwnTV_Core `player-core/.../subtitles/SubtitleController.kt` — `autoAttachProvider` 훅 추가
- OwnTV 앱 `OwnTVApp.kt` — 시작 시 폰트 설치 + 자막 프로바이더 등록
- `SubtitleOverlay.kt` — 커스텀 폰트 우선 적용
- 각 repo `tools/i18n/safe_literals.txt` — 기술 리터럴 등록 (i18n 검사 통과용)

## 파일 배치
```
owntv-patch/
├─ owntv-app.patch            # OwnTV repo에 git apply
├─ owntv-core.patch           # OwnTV_Core repo에 git apply
├─ OwnTVPlayer.kt             # → owntv-core/player-core/src/main/java/tv/own/owntv/player/
├─ SubtitleController.kt      # → owntv-core/player-core/src/main/java/tv/own/owntv/core/subtitles/
├─ app-src/tv/own/owntv/...   # → owntv/app/src/main/java/tv/own/owntv/ (동일 구조)
└─ assets/                    # → owntv/app/src/main/assets/ (자막·폰트 넣는 폴더 포함)
```

## 재빌드 방법 (PC, 8GB+ RAM 권장)
1. `git clone https://github.com/ahXN00/OwnTV` 및 `https://github.com/ahXN00/OwnTV_Core`
2. 위 파일들을 같은 상대 경로에 복사 (또는 `git apply owntv-core.patch` / `owntv-app.patch`)
3. 자막 파일 → `app/src/main/assets/subtitles/`, 폰트 → `app/src/main/assets/fonts/`
4. `~/.gradle/gradle.properties`에 `owntv.corePath=/경로/OwnTV_Core`
5. JDK 21 + Android SDK(platform 37)에서:
   `./gradlew :app:assembleStandardDebug`
6. 결과: `app/build/outputs/apk/standard/debug/app-standard-debug.apk`

## 빌드 검증 상태 (정직한 기록)
- 코어(OwnTV_Core) 컴파일+패키지: ✅ 성공 확인
- 앱 레이어 Kotlin: i18n 검사·리소스 병합 통과, 자체 신규 코드는 컴파일 통과
- 최종 APK: ❌ 이 샌드박스(2GB RAM)에서는 앱의 초대형 Compose 함수(OwnTVShell, ~13만자)
  컴파일/병합 단계에서 메모리 부족(OOM)으로 실패 — 일반 PC(8GB+)에서는 정상 빌드되는 규모
