package tv.own.owntv.player

import android.content.Context
import android.graphics.Typeface
import android.util.Log
import androidx.compose.ui.text.font.FontFamily

/**
 * Bundled custom subtitle font: the user drops a `.ttf` (or `.otf`) file into the app's
 * `assets/fonts/` folder before building/installing, and every subtitle — mpv's own rendering
 * AND the app-drawn overlay — then renders with that typeface.
 *
 * How it works:
 *  - [install] copies the font file into the engine's libass font directory (`cacheDir/subtitle-fonts`,
 *    the same folder [OwnTVPlayer.prepareSubtitleFontsDir] populates) so fontconfig can find it, and
 *    parses the file's internal family name (name table, id 16/1).
 *  - The family name is pushed to the engine via [OwnTVPlayer.customSubFontFamily]; mpv then uses
 *    `sub-font = <family>` wherever a subtitle font is applied.
 *  - [composeFamily] hands the same font to the Compose overlay (direct-render path) as an
 *    Android [Typeface].
 */
object CustomSubtitleFont {
    private const val TAG = "CustomSubFont"

    /** Asset folder the user puts their font file(s) into. The first .ttf/.otf wins. */
    const val ASSET_DIR = "fonts"

    /** The family name found in the bundled font, set by [install]. Null = no bundled font. */
    @Volatile
    var installedFamily: String? = null
        private set

    private var assetFileName: String? = null
    private var cachedTypeface: Typeface? = null

    /** Installs the bundled font, if any. Returns the font's family name, or null. */
    fun install(context: Context): String? {
        val names = runCatching {
            context.assets.list(ASSET_DIR)
                ?.filter { it.endsWith(".ttf", ignoreCase = true) || it.endsWith(".otf", ignoreCase = true) }
        }.getOrNull()
        val file = names?.firstOrNull() ?: return null
        return runCatching {
            val bytes = context.assets.open("$ASSET_DIR/$file").use { it.readBytes() }
            val family = ttfFamilyName(bytes) ?: file.substringBeforeLast('.')
            // Copy into the engine's font directory so libass/fontconfig can resolve the family.
            // The engine creates the same folder at mpv init; both can write it, files just persist.
            val dir = java.io.File(context.cacheDir, "subtitle-fonts").apply { mkdirs() }
            val safe = family.replace(Regex("[^A-Za-z0-9]"), "").ifEmpty { "CustomFont" }
            java.io.File(dir, "custom_$safe.ttf").apply {
                if (!isFile || length() != bytes.size.toLong()) writeBytes(bytes)
            }
            installedFamily = family
            assetFileName = file
            Log.i(TAG, "Custom subtitle font installed: $family ($file)")
            family
        }.onFailure {
            Log.w(TAG, "Custom subtitle font install failed: ${it.message}")
        }.getOrNull()
    }

    /** Compose [FontFamily] for the app-drawn overlay; null when no font is bundled. */
    fun composeFamily(context: Context): FontFamily? {
        val file = assetFileName ?: return null
        cachedTypeface?.let { return FontFamily(it) }
        return runCatching {
            val tf = Typeface.createFromAsset(context.assets, "$ASSET_DIR/$file")
            cachedTypeface = tf
            FontFamily(tf)
        }.onFailure { Log.w(TAG, "Could not load custom font for overlay: ${it.message}") }.getOrNull()
    }

    /**
     * Reads the font's family name straight from the sfnt `name` table (no extra dependency):
     * name id 16 (typographic family) preferred, falls back to id 1 (family). Handles TTF, OTF
     * and TTC containers. Returns null when nothing can be parsed — the caller then uses the file name.
     */
    private fun ttfFamilyName(b: ByteArray): String? = runCatching {
        fun u16(o: Int): Int = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
        fun u32(o: Int): Long = (u16(o).toLong() shl 16) or u16(o + 2).toLong()
        var base = 0
        if (u32(0) == 0x74746366L) base = u32(12).toInt() // 'ttcf' collection: first font
        val numTables = u16(base + 4)
        var nameOff = -1
        for (i in 0 until numTables) {
            val rec = base + 12 + i * 16
            if (u32(rec) == 0x6E616D65L) { nameOff = u32(rec + 8).toInt(); break } // 'name'
        }
        if (nameOff < 0) return null
        val count = u16(nameOff + 2)
        val strOff = u16(nameOff + 4)
        var family: String? = null
        for (i in 0 until count) {
            val rec = nameOff + 6 + i * 12
            val platform = u16(rec)
            val nameId = u16(rec + 6)
            val len = u16(rec + 8)
            val off = u16(rec + 10)
            val start = nameOff + strOff + off
            if (start < 0 || start + len > b.size) continue
            if ((nameId == 1 || nameId == 16) && (platform == 3 || platform == 0)) {
                val s = String(b, start, len, Charsets.UTF_16BE).trim()
                if (s.isNotBlank()) {
                    family = s
                    if (nameId == 16) break
                }
            }
        }
        family
    }.getOrNull()
}
