package tv.own.owntv.player

import android.content.Context
import android.util.Log
import org.json.JSONObject

/**
 * Bundled subtitles: the user drops `.srt`/`.vtt`/`.ass`/`.ssa` files into the app's
 * `assets/subtitles/` folder before building/installing, and whenever a movie or episode starts
 * playing, a matching file is attached to the running player AND selected automatically — the
 * subtitle plays along with the video with zero user action.
 *
 * Matching, in order (first hit wins):
 *  1. `assets/subtitles/mapping.json` — `{"<part of the video title>": "<subtitle file>"}`
 *     (case-insensitive substring match against the playing title).
 *  2. File-name identity — the subtitle file's name (without extension, punctuation stripped)
 *     equals the playing title the same way, e.g. `Big Buck Bunny.srt` matches the movie "Big Buck Bunny".
 *  3. Exactly ONE subtitle file is bundled — it is treated as "the" subtitle and attached to
 *     every movie/episode playback (turn it off with the player's subtitle button if ever needed).
 *
 * Files are copied to real storage on first use (assets can't be handed to a player), attached via
 * [OwnTVPlayer.addExternalSubtitle] which selects the track immediately.
 */
object BundledSubtitles {
    private const val TAG = "BundledSubs"

    /** Asset folder the user puts subtitle files into. */
    const val ASSET_DIR = "subtitles"

    private val EXTENSIONS = listOf("srt", "vtt", "ass", "ssa", "sub")

    /** The hook the engine's subtitle layer calls on every VOD file load (see SubtitleController). */
    fun provider(context: Context): (String?) -> List<OwnTVPlayer.ExternalSub> {
        return { title -> match(context, title) }
    }

    /** Subtitles bundled in the app right now (file names only — no copying). */
    fun bundledFiles(context: Context): List<String> = runCatching {
        context.assets.list(ASSET_DIR)?.filter { it.substringAfterLast('.').lowercase() in EXTENSIONS }
    }.getOrNull() ?: emptyList()

    fun match(context: Context, title: String?): List<OwnTVPlayer.ExternalSub> {
        val files = bundledFiles(context)
        if (files.isEmpty()) return emptyList()
        val map = runCatching {
            val raw = context.assets.open("$ASSET_DIR/mapping.json").use { it.bufferedReader().readText() }
            val o = JSONObject(raw)
            o.keys().asSequence().associate { it to o.getString(it) }
        }.getOrNull() ?: emptyMap()

        val picks = LinkedHashSet<String>()
        if (!title.isNullOrBlank()) {
            // 1. mapping.json — any key contained in the playing title.
            map.entries.firstOrNull { title.contains(it.key, ignoreCase = true) }?.let { picks.add(it.value) }
            // 2. File-name identity.
            val nt = normalize(title)
            files.firstOrNull { normalize(it.substringBeforeLast('.')) == nt }?.let { picks.add(it) }
        }
        // 3. One bundled subtitle = attach it everywhere.
        if (picks.isEmpty() && files.size == 1) picks.add(files.first())
        if (picks.isEmpty()) return emptyList()

        val dir = java.io.File(context.filesDir, "bundled-subs").apply { mkdirs() }
        return picks.mapNotNull { file ->
            runCatching {
                val target = java.io.File(dir, file)
                if (!target.isFile || target.length() == 0L) {
                    context.assets.open("$ASSET_DIR/$file").use { input ->
                        target.outputStream().use { input.copyTo(it) }
                    }
                }
                OwnTVPlayer.ExternalSub(
                    path = target.absolutePath,
                    title = file.substringBeforeLast('.'),
                    lang = null,
                    source = ExternalSubtitleSource.LOCAL,
                )
            }.onFailure { Log.w(TAG, "Could not stage bundled subtitle $file: ${it.message}") }.getOrNull()
        }
    }

    /** Lower-case letters and digits only — folds away spaces, dots, brackets and quality tags. */
    private fun normalize(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }
}
