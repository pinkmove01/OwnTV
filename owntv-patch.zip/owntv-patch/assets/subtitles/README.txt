여기에 자막 파일(.srt/.vtt/.ass/.ssa/.sub)을 넣고 앱을 다시 빌드하세요.

자동 매칭 규칙 (위에서부터 순서대로 적용):
1. mapping.json  - {"영상제목일부": "자막파일.srt"} 형태. 제목에 키가 포함되면 매칭.
2. 파일명 일치   - 예: 영화 제목 "Big Buck Bunny" -> "Big Buck Bunny.srt"
3. 자막이 1개뿐이면 모든 영화/에피소드 재생 시 자동으로 붙어 재생됩니다.

매핑 예시 (mapping.json):
{
  "빅벅버니": "bunny_ko.srt",
  "Interstellar": "interstellar_ko.srt"
}
